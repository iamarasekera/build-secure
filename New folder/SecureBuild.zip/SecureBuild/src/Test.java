
//Creating annotation  
import java.io.FileInputStream;
import java.lang.annotation.*;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarInputStream;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@interface BuildSecure {
	int value();
}

// Applying annotation
class AndroidCodeSample {
	@BuildSecure(value = 10)
	public void methodOne() {
		System.out.println("build Secure annotation");
	}
}

// Accessing annotation
class TestCustomAnnotation1 {
	public static void main(String args[]) throws Exception {
		// String jarFileName = "C:/git/gitlab/build-secure/bin/MyApp.apk";
		// String jarFileName = "c:/Tools/libs/cdi-api-1.1.jar";
		String jarFileName = "C:/apps/jdk/1.8.0_144/jre/lib/rt.jar";
		try (FileInputStream fis = new FileInputStream(jarFileName);
				JarInputStream jiStream = new JarInputStream(fis);) {
			List<String> listofClasses = new ArrayList<>();

			JarEntry jEntry;

			while ((jEntry = jiStream.getNextJarEntry()) != null) {
				if ((jEntry.getName().endsWith(".class"))) {
					String className = jEntry.getName().replaceAll("/", "\\.");
					String myClass = className.substring(0, className.lastIndexOf('.'));
					listofClasses.add(myClass);
				}
			}

			for (String javaClassName : listofClasses) {
				System.out.println(javaClassName);

				try {
					Class<?> superClass = Class.forName(javaClassName).getSuperclass();

					System.out.println(superClass);
					System.out.println(Object.class.getSuperclass()); 
					System.out.println(String[][].class.getSuperclass());
				} catch (RuntimeException |  Error re) {
					System.out.println("-------------" + re.getMessage());
				}
			}
		} catch (Exception e) {
			System.out.println("Oops.. Encounter an issue while parsing jar" + e.toString());
		}

		AndroidCodeSample h = new AndroidCodeSample();
		Method m = h.getClass().getMethod("methodOne");

		BuildSecure manno = m.getAnnotation(BuildSecure.class);
		System.out.println("value is: " + manno.value());
	}
}