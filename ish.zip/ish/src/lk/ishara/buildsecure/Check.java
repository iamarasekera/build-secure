package lk.ishara.buildsecure;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

import lk.ishara.buildsecure.core.BuildSecure;
import lk.ishara.buildsecure.core.BuildSecureInfo;

public class Check {

	public static void main(String[] args) throws Exception {

		System.out.println("Validating and checking security...");

		int passed = 0, failed = 0, count = 0, ignore = 0;

		Class<TestAndVerifySecurity> obj = TestAndVerifySecurity.class;

		// Process @BuildSecureInfo
		if (obj.isAnnotationPresent(BuildSecureInfo.class)) {

			Annotation annotation = obj.getAnnotation(BuildSecureInfo.class);
			BuildSecureInfo testerInfo = (BuildSecureInfo) annotation;

			System.out.printf("%nPriority :%s", testerInfo.priority());
			System.out.printf("%nCreatedBy :%s", testerInfo.verifiedBy());
			System.out.printf("%nTags :");

			int tagLength = testerInfo.tags().length;
			for (String tag : testerInfo.tags()) {
				if (tagLength > 1) {
					System.out.print(tag + ", ");
				} else {
					System.out.print(tag);
				}
				tagLength--;
			}

			System.out.printf("%nLastModified :%s%n%n", testerInfo.lastModified());

		}

		// Process @BuildSecure
		for (Method method : obj.getDeclaredMethods()) {

			// if method is annotated with @BuildSecure
			if (method.isAnnotationPresent(BuildSecure.class)) {

				Annotation annotation = method.getAnnotation(BuildSecure.class);
				BuildSecure buildTest = (BuildSecure) annotation;

				// if enabled = true (default)
				if (buildTest.enabled()) {

					try {
						method.invoke(obj.newInstance());
						System.out.printf("%s - Test '%s' - passed %n", ++count, method.getName());
						passed++;
					} catch (Throwable ex) {
						System.out.printf("%s - Test '%s' - failed: %s %n", ++count, method.getName(), ex.getCause());
						failed++;
					}

				} else {
					System.out.printf("%s - Test '%s' - ignored%n", ++count, method.getName());
					ignore++;
				}

			}

		}
		System.out.printf("%nResult : Total : %d, Passed: %d, Failed %d, Ignore %d%n", count, passed, failed, ignore);

	}
}