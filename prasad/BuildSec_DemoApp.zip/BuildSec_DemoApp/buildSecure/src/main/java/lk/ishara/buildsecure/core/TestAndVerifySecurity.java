package lk.ishara.buildsecure.core;

import lk.ishara.buildsecure.core.BuildSecure;
import lk.ishara.buildsecure.core.BuildSecureInfo;
import lk.ishara.buildsecure.core.BuildSecureInfo.Priority;

@BuildSecureInfo(priority = Priority.HIGH, verifiedBy = "ishara.lk", permission = {BuildSecureInfo.Permission.CAMERA, BuildSecureInfo.Permission.SEND_SMS })
public class TestAndVerifySecurity {

	@BuildSecure
	void testMediaAccess() {
		if (true)
			throw new RuntimeException("This test always failed");
	}

	@BuildSecure(enabled = false)
	void testUSBDriverAccess() {
		if (false)
			throw new RuntimeException("This test always passed");
	}

	@BuildSecure(enabled = true)
	void testExternalSDCardAccess() {
		if (10 > 1) { // include valid checks
			// do nothing, this test always passed.
		}
	}
	@Override
	public String toString(){
		return this.getClass().getCanonicalName().toString();
	}

}